import {
  MessageType,
  UnitType,
  GameConfig,
  GameState,
  InitMessage,
  UpdateMessage,
  GameOverMessage,
  SpawnMessage,
  JoinMessage,
  ServerMessage,
  ClientMessage
} from '../common/types.js';

/**
 * The main client module orchestrates the WebSocket connection,
 * user interface and rendering loop. It listens for messages from
 * the server and updates the local representation of the game
 * accordingly.
 */

const canvas = document.getElementById('gameCanvas') as HTMLCanvasElement;
const ctx = canvas.getContext('2d')!;

const manaBar = document.getElementById('manaBar') as HTMLDivElement;
const manaFill = document.getElementById('manaFill') as HTMLDivElement;
const handDiv = document.getElementById('hand') as HTMLDivElement;

let socket: WebSocket;
let playerId: number | null = null;
let config: GameConfig | null = null;
let state: GameState | null = null;
let selectedType: UnitType = UnitType.Melee;
// Bounding boxes for cards used for hit detection if we choose to draw them on canvas

/** Initialize the WebSocket connection and UI. */
function initConnection() {
  // Determine server address. The user can specify a query parameter
  // 'host' to override the default. Example: ?host=ws://192.168.0.10:8080
  const params = new URLSearchParams(window.location.search);
  const hostParam = params.get('host');
  // Use window.location.hostname by default; fallback to localhost when not served via http(s)
  const defaultHost = window.location.hostname ? window.location.hostname : 'localhost';
  const url = hostParam ?? `ws://${defaultHost}:8080`;
  socket = new WebSocket(url);
  socket.addEventListener('open', () => {
    // Send join message
    const joinMsg: JoinMessage = { type: MessageType.Join };
    socket.send(JSON.stringify(joinMsg));
  });
  socket.addEventListener('message', (event) => {
    let message: ServerMessage;
    try {
      message = JSON.parse(event.data);
    } catch (err) {
      console.error('Failed to parse server message', err);
      return;
    }
    handleServerMessage(message);
  });
  socket.addEventListener('close', () => {
    displayOverlay('Verbindung zum Server verloren');
  });
  socket.addEventListener('error', () => {
    displayOverlay('Fehler beim Verbindungsaufbau');
  });
}

/** Process messages received from the server. */
function handleServerMessage(message: ServerMessage): void {
  switch (message.type) {
    case MessageType.Init: {
      const initMsg = message as InitMessage;
      playerId = initMsg.playerId;
      config = initMsg.config;
      state = initMsg.state;
      // Adjust canvas dimensions to config
      canvas.width = config.boardWidth;
      canvas.height = config.boardHeight;
      removeOverlay();
      initUI();
      requestAnimationFrame(render);
      break;
    }
    case MessageType.Update: {
      const updateMsg = message as UpdateMessage;
      state = updateMsg.state;
      break;
    }
    case MessageType.GameOver: {
      const gameOverMsg = message as GameOverMessage;
      const winner = gameOverMsg.winner;
      const msg = winner === playerId ? 'Du hast gewonnen!' : 'Du hast verloren.';
      displayOverlay(msg);
      break;
    }
    case MessageType.Error: {
      displayOverlay((message as any).message ?? 'Unbekannter Fehler');
      break;
    }
    default:
      break;
  }
}

/** Create card elements and set up interaction handlers. */
function initUI(): void {
  if (!config) return;
  // Create card elements only once
  handDiv.innerHTML = '';
  const cardTypes: UnitType[] = [UnitType.Melee, UnitType.Archer, UnitType.Tank];
  cardTypes.forEach((type) => {
    const card = document.createElement('div');
    card.classList.add('card');
    card.dataset.type = type;
    // Use first letter uppercase as symbol
    const letter = type === UnitType.Melee ? 'M' : type === UnitType.Archer ? 'A' : 'T';
    card.innerHTML = `<strong>${letter}</strong><small>Mana: ${config!.unitCosts[type]}</small>`;
    card.addEventListener('click', () => {
      selectedType = type;
      updateCardSelection();
    });
    handDiv.appendChild(card);
  });
  updateCardSelection();
  // Setup pointer handling on canvas
  canvas.addEventListener('pointerdown', (ev) => {
    if (playerId === null || !config || !state || !state.running) return;
    // Determine lane index based on y coordinate. Choose the nearest lane by absolute difference.
    const rect = canvas.getBoundingClientRect();
    const y = ev.clientY - rect.top;
    let laneIndex = 0;
    let minDist = Number.POSITIVE_INFINITY;
    config.lanes.forEach((lane, idx) => {
      const dist = Math.abs(lane.y - y);
      if (dist < minDist) {
        minDist = dist;
        laneIndex = idx;
      }
    });
    // Only allow spawning on your side of the board: player 0 on left half, player 1 on right half
    const x = ev.clientX - rect.left;
    if (playerId === 0 && x > config.boardWidth / 2) return;
    if (playerId === 1 && x < config.boardWidth / 2) return;
    // Check mana
    const cost = config.unitCosts[selectedType];
    const player = state.players[playerId];
    if (player.mana < cost) return;
    // Send spawn message
    const spawnMsg: SpawnMessage = {
      type: MessageType.Spawn,
      lane: laneIndex,
      unitType: selectedType
    };
    socket.send(JSON.stringify(spawnMsg));
  });
}

/** Update visual selection highlight for cards. */
function updateCardSelection(): void {
  const cards = handDiv.querySelectorAll<HTMLElement>('.card');
  cards.forEach((el) => {
    if (el.dataset.type === selectedType) {
      el.classList.add('selected');
    } else {
      el.classList.remove('selected');
    }
  });
}

/** Update the mana bar width based on the player's current mana. */
function updateManaBar(): void {
  if (!state || playerId === null) return;
  const player = state.players[playerId];
  const percent = (player.mana / player.maxMana) * 100;
  manaFill.style.width = `${percent}%`;
}

/** Apply disabled styling to cards for which the player has insufficient mana. */
function updateCardAvailability(): void {
  if (!state || !config || playerId === null) return;
  const player = state.players[playerId];
  const cards = handDiv.querySelectorAll<HTMLElement>('.card');
  cards.forEach((el) => {
    const type = el.dataset.type as UnitType;
    const cost = config!.unitCosts[type];
    if (player.mana < cost) {
      el.classList.add('disabled');
    } else {
      el.classList.remove('disabled');
    }
  });
}

/** Render the game board and entities. */
function render(): void {
  if (!config || !state) {
    requestAnimationFrame(render);
    return;
  }
  const bw = config.boardWidth;
  const bh = config.boardHeight;
  // Clear canvas
  ctx.clearRect(0, 0, bw, bh);
  // Draw background split for each side
  ctx.fillStyle = '#eef2ff'; // light blue for host side
  ctx.fillRect(0, 0, bw / 2, bh);
  ctx.fillStyle = '#fef2f2'; // light red for guest side
  ctx.fillRect(bw / 2, 0, bw / 2, bh);
  // Draw lanes as horizontal lines
  ctx.strokeStyle = '#94a3b8';
  ctx.lineWidth = 1;
  config.lanes.forEach((lane) => {
    ctx.beginPath();
    ctx.moveTo(0, lane.y);
    ctx.lineTo(bw, lane.y);
    ctx.stroke();
  });
  // Draw bases. We'll render them as vertical rectangles hugging the edges.
    state.bases.forEach((base, idx) => {
    const baseWidth = config!.baseSize;
    const x = idx === 0 ? 0 : bw - baseWidth;
    const y = 0;
    const h = bh;
    ctx.fillStyle = idx === 0 ? '#2563eb' : '#dc2626';
    ctx.fillRect(x, y, baseWidth, h);
    // HP bar at top of base
    const hpPercent = base.hp / base.maxHp;
    const barWidth = baseWidth;
    const barHeight = 5;
    const barX = x;
    const barY = 0;
    // background bar
    ctx.fillStyle = '#334155';
    ctx.fillRect(barX, barY, barWidth, barHeight);
    ctx.fillStyle = '#22c55e';
    ctx.fillRect(barX, barY, barWidth * hpPercent, barHeight);
    ctx.strokeStyle = '#0f172a';
    ctx.strokeRect(barX, barY, barWidth, barHeight);
  });
  // Draw units
  state.units.forEach((unit) => {
    const radius = 10;
    ctx.fillStyle = unit.owner === 0 ? '#3b82f6' : '#ef4444';
    ctx.beginPath();
    ctx.arc(unit.x, unit.y, radius, 0, Math.PI * 2);
    ctx.fill();
    // HP bar above unit
    const hpWidth = 20;
    const hpHeight = 3;
    const hpX = unit.x - hpWidth / 2;
    const hpY = unit.y - radius - 8;
    const hpPercent = unit.hp / unit.maxHp;
    ctx.fillStyle = '#475569';
    ctx.fillRect(hpX, hpY, hpWidth, hpHeight);
    ctx.fillStyle = '#22c55e';
    ctx.fillRect(hpX, hpY, hpWidth * hpPercent, hpHeight);
    ctx.strokeStyle = '#0f172a';
    ctx.strokeRect(hpX, hpY, hpWidth, hpHeight);
  });
  // Update UI elements
  updateManaBar();
  updateCardAvailability();
  requestAnimationFrame(render);
}

/** Display an overlay message to the user. Used for errors and end-of-game messages. */
function displayOverlay(message: string): void {
  let overlay = document.getElementById('overlay') as HTMLDivElement | null;
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'overlay';
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.display = 'flex';
    overlay.style.alignItems = 'center';
    overlay.style.justifyContent = 'center';
    overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.6)';
    overlay.style.color = '#fff';
    overlay.style.fontSize = '24px';
    overlay.style.zIndex = '999';
    document.body.appendChild(overlay);
  }
  overlay.textContent = message;
}

/** Remove the overlay if present. */
function removeOverlay(): void {
  const overlay = document.getElementById('overlay');
  if (overlay) overlay.remove();
}

// Initialize connection and start waiting for messages
initConnection();