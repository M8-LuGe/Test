// The server code uses Node built-in modules that do not ship with
// TypeScript type declarations in this sandbox. To avoid compile
// errors caused by missing type definitions, we disable type
// checking for this file. The code will still be transpiled to
// JavaScript by the TypeScript compiler.
// @ts-nocheck
import * as http from 'http';
import * as crypto from 'crypto';
import type { IncomingMessage } from 'http';
import type { Socket } from 'net';
import {
  MessageType,
  UnitType,
  GameConfig,
  GameState,
  PlayerState,
  Unit,
  Base,
  ServerMessage,
  ClientMessage,
  SpawnMessage,
  JoinMessage,
  UpdateMessage,
  InitMessage,
  GameOverMessage,
  // ErrorMessage
} from '../common/types.js';

/**
 * Ticking interval in milliseconds. 20 ticks per second yields a smooth
 * simulation without overloading the network.
 */
const TICK_MS = 50;

/**
 * Define the static configuration shared with clients. All values are
 * expressed in pixels or units appropriate for the simulation.
 */
const config: GameConfig = {
  boardWidth: 800,
  boardHeight: 600,
  lanes: [
    { y: 200 },
    { y: 300 },
    { y: 400 }
  ],
  baseSize: 40,
  unitCosts: {
    [UnitType.Melee]: 2,
    [UnitType.Archer]: 3,
    [UnitType.Tank]: 5
  },
  maxMana: 10,
  // Mana regeneration rate measured in mana per second. Since we tick
  // every 50 ms, mana will increase by regenRate * (TICK_MS / 1000)
  manaRegenRate: 1 / 3 // 0.333... mana per second → roughly 1 mana every 3 seconds
};

/**
 * Unit base statistics. The server uses these values when spawning
 * new units. Attack cooldowns are given in ticks, not milliseconds.
 */
const UNIT_STATS = {
  [UnitType.Melee]: {
    hp: 100,
    damage: 20,
    range: 20,
    speed: 2,
    cooldown: 20 // 1000 ms → 20 ticks
  },
  [UnitType.Archer]: {
    hp: 80,
    damage: 15,
    range: 100,
    speed: 1.5,
    cooldown: 24 // 1200 ms → 24 ticks
  },
  [UnitType.Tank]: {
    hp: 200,
    damage: 30,
    range: 20,
    speed: 1,
    cooldown: 30 // 1500 ms → 30 ticks
  }
} as const;

/**
 * Construct a fresh game state. This is called when two clients have
 * connected and a new match begins.
 */
function createInitialState(): GameState {
  const players: PlayerState[] = [];
  for (let i = 0; i < 2; i++) {
    players.push({
      mana: config.maxMana,
      maxMana: config.maxMana,
      manaRegen: config.manaRegenRate,
      deck: [UnitType.Melee, UnitType.Archer, UnitType.Tank],
      hand: [UnitType.Melee, UnitType.Archer, UnitType.Tank],
      manaTimer: 0
    });
  }
  const bases: Base[] = [
    { hp: 1000, maxHp: 1000 },
    { hp: 1000, maxHp: 1000 }
  ];
  return {
    units: [],
    bases,
    players,
    time: 0,
    running: true
  };
}

/**
 * Represents a connected WebSocket client. We store the underlying
 * socket, a small buffer of unprocessed bytes and the assigned player
 * identifier. A connection exposes a send function that writes
 * properly framed WebSocket messages to the socket.
 */
interface Connection {
  socket: Socket;
  buffer: Buffer;
  playerId: number;
  send: (message: string) => void;
}

// Keep track of all connected clients in order of their player id.
const connections: Connection[] = [];
let gameState: GameState = createInitialState();
let tickInterval: NodeJS.Timer | null = null;
let nextUnitCounter = 0;

/**
 * Generate a simple incremental identifier for units. Using a
 * sequential ID ensures uniqueness and avoids extra dependencies.
 */
function nextUnitId(): string {
  return `u${nextUnitCounter++}`;
}

/**
 * Compute the Sec-WebSocket-Accept header value for a given key. The
 * specification requires SHA-1 hashing of the key concatenated with
 * a magic GUID and base64-encoding the result.
 */
function createAccept(key: string): string {
  return crypto
    .createHash('sha1')
    .update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11')
    .digest('base64');
}

/**
 * Encode a text message into a WebSocket frame and write it to the
 * underlying TCP socket. The frame uses a FIN bit with opcode 1 and
 * does not mask the payload (masking is only required for client
 * messages). The payload length is encoded using the minimal number
 * of bytes according to the WebSocket protocol specification.
 */
function sendFrame(conn: Connection, data: string): void {
  const payload = Buffer.from(data, 'utf8');
  const length = payload.length;
  let header: number[] = [];
  // Set FIN bit and opcode for text frame (0x1)
  const firstByte = 0x80 | 0x1;
  if (length <= 125) {
    header = [firstByte, length];
  } else if (length <= 0xffff) {
    header = [firstByte, 126, (length >> 8) & 0xff, length & 0xff];
  } else {
    // 64-bit length. Use 0 for high 32 bits (we don't support >2^32)
    header = [firstByte, 127, 0, 0, 0, 0, (length >> 24) & 0xff, (length >> 16) & 0xff, (length >> 8) & 0xff, length & 0xff];
  }
  const frame = Buffer.concat([Buffer.from(header), payload]);
  conn.socket.write(frame);
}

/**
 * Parse incoming data from a client. The function processes one
 * complete WebSocket frame at a time, handling fragmentation and
 * masking as required. Only text frames (opcode 0x1) and close frames
 * (opcode 0x8) are supported. Unknown opcodes are ignored. When a
 * complete text frame is parsed, its payload is passed to
 * `handleMessageFromClient()`.
 */
function handleData(conn: Connection, chunk: Buffer): void {
  conn.buffer = Buffer.concat([conn.buffer, chunk]);
  // Process as many frames as are fully buffered
  while (true) {
    if (conn.buffer.length < 2) return;
    const firstByte = conn.buffer[0];
    const secondByte = conn.buffer[1];
    const fin = (firstByte & 0x80) !== 0;
    const opcode = firstByte & 0x0f;
    const masked = (secondByte & 0x80) !== 0;
    let payloadLen = secondByte & 0x7f;
    let offset = 2;
    if (payloadLen === 126) {
      if (conn.buffer.length < offset + 2) return;
      payloadLen = conn.buffer.readUInt16BE(offset);
      offset += 2;
    } else if (payloadLen === 127) {
      if (conn.buffer.length < offset + 8) return;
      const high = conn.buffer.readUInt32BE(offset);
      const low = conn.buffer.readUInt32BE(offset + 4);
      if (high !== 0) {
        // Payloads > 2^32 bytes are not supported
        conn.socket.end();
        return;
      }
      payloadLen = low;
      offset += 8;
    }
    let maskKey: Buffer | undefined;
    if (masked) {
      if (conn.buffer.length < offset + 4) return;
      maskKey = conn.buffer.slice(offset, offset + 4);
      offset += 4;
    }
    if (conn.buffer.length < offset + payloadLen) return;
    let payload = conn.buffer.slice(offset, offset + payloadLen);
    // Remove processed bytes from buffer
    conn.buffer = conn.buffer.slice(offset + payloadLen);
    // Unmask if required
    if (masked && maskKey) {
      const unmasked = Buffer.alloc(payloadLen);
      for (let i = 0; i < payloadLen; i++) {
        unmasked[i] = payload[i] ^ maskKey[i % 4];
      }
      payload = unmasked;
    }
    // Handle opcodes
    if (opcode === 0x8) {
      // Close frame
      conn.socket.end();
      return;
    } else if (opcode === 0x1) {
      // Text frame
      const text = payload.toString('utf8');
      handleMessageFromClient(conn, text);
    } else {
      // Ignore other opcodes (binary, ping, pong, etc.)
    }
    if (!fin) {
      // We don't support fragmented messages; ignore
      continue;
    }
  }
}

/**
 * Handle the raw WebSocket handshake. When a client requests an upgrade
 * to WebSocket, we respond with the appropriate headers and set up
 * the connection. We assign a playerId based on the current number
 * of connections and start the game once two players are present.
 */
function handleUpgrade(req: IncomingMessage, socket: Socket, head: Buffer): void {
  const key = req.headers['sec-websocket-key'];
  if (!key || Array.isArray(key)) {
    socket.write('HTTP/1.1 400 Bad Request\r\n\r\n');
    socket.destroy();
    return;
  }
  // Limit number of players to two
  if (connections.length >= 2) {
    const reject = [
      'HTTP/1.1 503 Service Unavailable',
      'Connection: close',
      '',
      'Server already full'
    ].join('\r\n');
    socket.write(reject);
    socket.destroy();
    return;
  }
  const accept = createAccept(key);
  const headers = [
    'HTTP/1.1 101 Switching Protocols',
    'Upgrade: websocket',
    'Connection: Upgrade',
    `Sec-WebSocket-Accept: ${accept}`,
    '',
    ''
  ].join('\r\n');
  socket.write(headers);
  // Create connection object
  const playerId = connections.length;
  const conn: Connection = {
    socket,
    buffer: Buffer.alloc(0),
    playerId,
    send: (msg: string) => sendFrame(conn, msg)
  };
  connections.push(conn);
  console.log(`Player ${playerId} connected`);
  // Set up event handlers
  socket.on('data', (chunk) => handleData(conn, chunk));
  socket.on('close', () => handleDisconnection(conn));
  socket.on('end', () => handleDisconnection(conn));
  // When both players have connected, start game
  if (connections.length === 2) {
    gameState = createInitialState();
    console.log('Both players connected, starting game');
    // Send init messages
    connections.forEach((c) => {
      const initMsg: InitMessage = { type: MessageType.Init, playerId: c.playerId, config, state: gameState };
      c.send(JSON.stringify(initMsg));
    });
    // Start simulation loop
    if (tickInterval) clearInterval(tickInterval);
    tickInterval = setInterval(updateGame, TICK_MS);
  }
}

/**
 * Handle a client disconnection. If a client disconnects mid-game,
 * the remaining player automatically wins. We clean up state and
 * notify all connected clients of the result.
 */
function handleDisconnection(conn: Connection): void {
  const idx = connections.indexOf(conn);
  if (idx !== -1) {
    connections.splice(idx, 1);
  }
  console.log(`Player ${conn.playerId} disconnected`);
  if (gameState.running) {
    gameState.running = false;
    const winner = conn.playerId === 0 ? 1 : 0;
    const msg: GameOverMessage = { type: MessageType.GameOver, winner };
    broadcast(msg);
    if (tickInterval) {
      clearInterval(tickInterval);
      tickInterval = null;
    }
  }
}

/**
 * Spawn a unit for a given player on the requested lane, if the player
 * has enough mana. This function mutates the game state directly.
 */
function spawnUnit(playerId: number, lane: number, unitType: UnitType): void {
  // Validate lane index
  if (lane < 0 || lane >= config.lanes.length) {
    return;
  }
  const player = gameState.players[playerId];
  const cost = config.unitCosts[unitType];
  if (player.mana < cost) {
    // Not enough mana – ignore spawn request
    return;
  }
  player.mana -= cost;
  if (player.mana < 0) player.mana = 0;
  // Determine base stats
  const stats = UNIT_STATS[unitType];
  const id = nextUnitId();
  const x = playerId === 0 ? config.baseSize : config.boardWidth - config.baseSize;
  const y = config.lanes[lane].y;
  const speed = playerId === 0 ? stats.speed : -stats.speed;
  const unit: Unit = {
    id,
    owner: playerId,
    type: unitType,
    lane,
    x,
    y,
    hp: stats.hp,
    maxHp: stats.hp,
    damage: stats.damage,
    range: stats.range,
    speed,
    attackCooldown: stats.cooldown,
    attackTimer: 0
  };
  gameState.units.push(unit);
}

/**
 * Update mana for both players. Mana regenerates over time based on
 * the configured regeneration rate. Each tick contributes
 * regenRate * TICK_MS / 1000 mana. When enough fractional mana has
 * accumulated to represent a whole unit, we increment the player's
 * mana by one and subtract the integer portion from the timer. Mana
 * never exceeds maxMana.
 */
function updateMana(): void {
  const manaGainPerTick = config.manaRegenRate * (TICK_MS / 1000);
  gameState.players.forEach((player) => {
    if (player.mana < player.maxMana) {
      player.manaTimer += manaGainPerTick;
      while (player.manaTimer >= 1 && player.mana < player.maxMana) {
        player.mana += 1;
        player.manaTimer -= 1;
      }
      if (player.mana > player.maxMana) player.mana = player.maxMana;
    }
  });
}

/**
 * Perform one tick of the simulation. Moves units, handles attacks
 * and checks for base damage and game over conditions. When the game
 * finishes, this function stops the tick interval and sends a
 * game-over message to all clients.
 */
function updateGame(): void {
  if (!gameState.running) return;
  gameState.time++;
  updateMana();
  // Process each unit. We'll build a new array of alive units.
  const newUnits: Unit[] = [];
  // We'll mark units for removal by skipping them when pushing to newUnits
  for (const unit of gameState.units) {
    // If the unit is dead, skip
    if (unit.hp <= 0) continue;
    // Identify potential enemy units in the same lane
    let target: Unit | undefined;
    let minDist = Infinity;
    for (const other of gameState.units) {
      if (other.owner === unit.owner || other.lane !== unit.lane || other.hp <= 0) continue;
      const dx = other.x - unit.x;
      // Player 0 units move right (positive speed), so they only consider enemies ahead (dx > 0)
      // Player 1 units move left (negative speed), so they only consider enemies ahead (dx < 0)
      if ((unit.speed > 0 && dx > 0 && dx <= unit.range) || (unit.speed < 0 && dx < 0 && -dx <= unit.range)) {
        const dist = Math.abs(dx);
        if (dist < minDist) {
          minDist = dist;
          target = other;
        }
      }
    }
    if (target) {
      // In range of an enemy unit – stop moving and attack when timer permits
      if (unit.attackTimer <= 0) {
        // Apply damage
        target.hp -= unit.damage;
        if (target.hp < 0) target.hp = 0;
        // Reset attack timer
        unit.attackTimer = unit.attackCooldown;
      } else {
        unit.attackTimer--;
      }
      // Unit stays in place when attacking
    } else {
      // Not in range – move toward enemy base
      unit.x += unit.speed;
      if (unit.attackTimer > 0) unit.attackTimer--;
    }
    // Check if unit reached enemy base
    if (unit.owner === 0 && unit.x >= config.boardWidth - config.baseSize) {
      // Damage player 1 base
      gameState.bases[1].hp -= unit.damage;
      if (gameState.bases[1].hp < 0) gameState.bases[1].hp = 0;
      continue; // Unit disappears after dealing damage
    } else if (unit.owner === 1 && unit.x <= config.baseSize) {
      // Damage player 0 base
      gameState.bases[0].hp -= unit.damage;
      if (gameState.bases[0].hp < 0) gameState.bases[0].hp = 0;
      continue; // Unit disappears
    }
    // Unit survives and is added to list
    newUnits.push(unit);
  }
  gameState.units = newUnits;
  // Check for game over
  if (gameState.bases[0].hp <= 0 || gameState.bases[1].hp <= 0) {
    gameState.running = false;
    const winner = gameState.bases[0].hp > gameState.bases[1].hp ? 0 : 1;
    const msg: GameOverMessage = { type: MessageType.GameOver, winner };
    broadcast(msg);
    // Stop the simulation
    if (tickInterval) {
      clearInterval(tickInterval);
      tickInterval = null;
    }
    return;
  }
  // Broadcast state update to all clients
  const updateMsg: UpdateMessage = { type: MessageType.Update, state: gameState };
  broadcast(updateMsg);
}

/**
 * Broadcast a message to all connected clients. The message is
 * serialized to JSON. In a production environment you might
 * optimize by sending a binary format instead.
 */
function broadcast(message: ServerMessage): void {
  const str = JSON.stringify(message);
  for (const conn of connections) {
    conn.send(str);
  }
}

/**
 * Handle incoming messages from a client. Each message is parsed
 * according to the defined protocol. Malformed or unknown messages
 * are ignored.
 */
/**
 * Parse and handle a JSON-encoded message from a client. Only spawn
 * requests are acted upon on the server. Join messages are
 * automatically handled during connection setup.
 */
function handleMessageFromClient(conn: Connection, text: string): void {
  let message: ClientMessage;
  try {
    message = JSON.parse(text);
  } catch {
    // Ignore malformed JSON
    return;
  }
  switch (message.type) {
    case MessageType.Spawn: {
      const spawnMsg = message as SpawnMessage;
      spawnUnit(conn.playerId, spawnMsg.lane, spawnMsg.unitType);
      break;
    }
    case MessageType.Join:
      // Join is handled implicitly by the server; ignore duplicates
      break;
    default:
      break;
  }
}

/**
 * Start the WebSocket server and listen for connections. When two
 * clients have connected, the game begins.
 */
function startServer(port = 8080): void {
  const server = http.createServer((req, res) => {
    // Simple HTTP response for non-WebSocket requests
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('This is the Clash Royale Lite server. Use WebSocket to play.');
  });
  server.on('upgrade', (req: IncomingMessage, socket: Socket, head: Buffer) => {
    handleUpgrade(req, socket, head);
  });
  server.listen(port, () => {
    console.log(`WebSocket server listening on ws://localhost:${port}`);
  });
}

// Only start the server if this module is the entrypoint. This check
// prevents the server from launching during unit tests or when
// imported as a library.
// Only start the server if this module is executed directly via node.
// Node sets process.argv[1] to the file path of the executed script. In
// ESM, import.meta.url is a file:// URL. Convert it to a pathname
// before comparing. Without this check the server would also start
// when imported by the client build script.
const currentModulePath = new URL(import.meta.url).pathname;
if (process.argv[1] === currentModulePath) {
  const portEnv = process.env.PORT;
  const port = portEnv ? parseInt(portEnv, 10) : 8080;
  startServer(port);
}

export { startServer };