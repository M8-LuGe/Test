export enum MessageType {
  /**
   * Client -> Server: request to join the lobby. No payload required.
   */
  Join = 'join',
  /**
   * Server -> Client: sent once both players have connected. Contains
   * player identifier (0 or 1) and the static game configuration.
   */
  Init = 'init',
  /**
   * Client -> Server: request to spawn a unit on a given lane. The server
   * checks mana and either accepts or ignores the request.
   */
  Spawn = 'spawn',
  /**
   * Server -> Client: broadcasted every tick with the current game state.
   */
  Update = 'update',
  /**
   * Server -> Client: emitted when one of the bases has been destroyed.
   */
  GameOver = 'gameOver',
  /**
   * Server -> Client: error message if something goes wrong.
   */
  Error = 'error'
}

/** Types of units available in the game. */
export enum UnitType {
  Melee = 'melee',
  Archer = 'archer',
  Tank = 'tank'
}

/** A unit on the battlefield. Every unit moves along a lane and
 * attacks enemies in range. The server treats the state as the
 * authoritative version of the game world.
 */
export interface Unit {
  id: string;
  /** The owner of the unit: 0 for the host, 1 for the guest. */
  owner: number;
  type: UnitType;
  /** Index of lane the unit marches along. */
  lane: number;
  /** Horizontal position in pixels relative to the left edge of the board. */
  x: number;
  /** Vertical position in pixels; derived from lane. */
  y: number;
  /** Current and maximum hit points. */
  hp: number;
  maxHp: number;
  /** Damage dealt per attack. */
  damage: number;
  /** Attack range in pixels. */
  range: number;
  /** Horizontal movement speed in pixels per tick. Positive values move to the right, negative values to the left. */
  speed: number;
  /** Time between attacks in ticks. */
  attackCooldown: number;
  /** Countdown timer for the next attack. When it reaches zero, the unit can attack again. */
  attackTimer: number;
}

/** The bases for both players. Once a base's hit points drop to zero,
 * the game ends.
 */
export interface Base {
  hp: number;
  maxHp: number;
}

/** The per-player resource and card state. Mana regenerates over time
 * and is spent to deploy units. In this simple prototype, every
 * player has the same deck and hand.
 */
export interface PlayerState {
  mana: number;
  maxMana: number;
  manaRegen: number;
  /** The static deck of unit types available to a player. */
  deck: UnitType[];
  /** The current hand (subset of deck) shown to the player. */
  hand: UnitType[];
  /** Internal counter used by the server to drip mana over time. */
  manaTimer: number;
}

/** The full simulation state. This is transmitted from the server to
 * clients every tick. Clients should treat it as read-only and
 * render accordingly.
 */
export interface GameState {
  units: Unit[];
  bases: Base[];
  players: PlayerState[];
  /** Running time in ticks since the start of the match. */
  time: number;
  /** If true, the match is still ongoing. */
  running: boolean;
}

/** Lanes define the vertical positions where units travel. */
export interface Lane {
  y: number;
}

/** Static configuration shared between server and clients. */
export interface GameConfig {
  boardWidth: number;
  boardHeight: number;
  lanes: Lane[];
  baseSize: number;
  unitCosts: Record<UnitType, number>;
  maxMana: number;
  manaRegenRate: number;
}

/** Client -> Server: request to join the lobby. */
export interface JoinMessage {
  type: MessageType.Join;
}

/** Client -> Server: request to spawn a unit on a specific lane. */
export interface SpawnMessage {
  type: MessageType.Spawn;
  lane: number;
  unitType: UnitType;
}

/** Server -> Client: initial handshake when both players are present. */
export interface InitMessage {
  type: MessageType.Init;
  playerId: number;
  config: GameConfig;
  state: GameState;
}

/** Server -> Client: periodic state update. */
export interface UpdateMessage {
  type: MessageType.Update;
  state: GameState;
}

/** Server -> Client: final game over notification. */
export interface GameOverMessage {
  type: MessageType.GameOver;
  winner: number;
}

/** Server -> Client: error notification. */
export interface ErrorMessage {
  type: MessageType.Error;
  message: string;
}

export type ClientMessage = JoinMessage | SpawnMessage;
export type ServerMessage = InitMessage | UpdateMessage | GameOverMessage | ErrorMessage;