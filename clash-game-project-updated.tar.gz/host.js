#!/usr/bin/env node
// Helper script to act as the host. When executed, it starts the
// WebSocket server on the specified port (default 8080) and prints
// instructions to the console. This script must be run with Node.js.

// Import the compiled server module dynamically. The compiled file
// exports a startServer function which takes a port number and
// launches the WebSocket server.
import('./dist/server/server.js').then(({ startServer }) => {
  const portEnv = process.env.PORT;
  const port = portEnv ? parseInt(portEnv, 10) : 8080;
  startServer(port);
  console.log(`Multiplayer-Server läuft auf ws://localhost:${port}`);
  console.log('Öffne die Datei dist/client/index.html in deinem Browser, um das Match zu starten.');
}).catch((err) => {
  console.error('Fehler beim Start des Servers:', err);
});