#!/usr/bin/env node
// Copy static assets from the public directory into the distribution
// folder. This script runs after the TypeScript compiler emits
// JavaScript files. It ensures that index.html and other assets end
// up alongside the client bundle so that the game can be launched
// directly from the dist/client directory.

const fs = require('fs');
const path = require('path');

const projectRoot = path.resolve(__dirname, '..');
const publicDir = path.join(projectRoot, 'public');
const destDir = path.join(projectRoot, 'dist', 'client');

function copyRecursive(srcDir, destDir) {
  if (!fs.existsSync(destDir)) {
    fs.mkdirSync(destDir, { recursive: true });
  }
  const entries = fs.readdirSync(srcDir, { withFileTypes: true });
  for (const entry of entries) {
    const srcPath = path.join(srcDir, entry.name);
    const destPath = path.join(destDir, entry.name);
    if (entry.isDirectory()) {
      copyRecursive(srcPath, destPath);
    } else {
      if (entry.name === 'index.html') {
        let html = fs.readFileSync(srcPath, 'utf8');
        // Ensure the script tag references the compiled game bundle within the same directory
        html = html.replace(/src="\.\/game\.js"/, 'src="./game.js"');
        fs.writeFileSync(destPath, html, 'utf8');
      } else {
        fs.copyFileSync(srcPath, destPath);
      }
    }
  }
}

copyRecursive(publicDir, destDir);
console.log('Static assets copied to dist/client');